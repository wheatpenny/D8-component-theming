(function <%= dashlessName %>Script($, Drupal) {
  Drupal.behaviors.<%= dashlessName %> = {
    attach(context) {

    },
  };
}(jQuery, Drupal));
