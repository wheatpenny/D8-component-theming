To contribute to these tools, just modify as you see fit and push up a pull request!

### Contributing to `p2-theme-core` dependency

If you have an improvement, please contribute! Clone the [`p2-theme-core`](https://github.com/phase2/p2-theme-core) repo and then run this command while in this directory:

    npm link ../path/to/p2-theme-core

That will symlink `node_modules/p2-theme-core/` to the cloned `p2-theme-core` repo. 
