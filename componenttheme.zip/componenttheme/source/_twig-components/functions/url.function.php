<?php
// https://www.drupal.org/node/2486991
$function = new Twig_SimpleFunction('url', function ($string) {
  return '#';
});
